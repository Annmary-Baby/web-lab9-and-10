import React from 'react'
import { Link } from 'react-router-dom'
import BooksPage from './BooksPage'
import AboutPage from './AboutPage'
import ContactPage from './ContactPage'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

function Home() {
  return (
    <>
    <Navbar />
  



    <Footer />
    </>
  )
}

export default Home