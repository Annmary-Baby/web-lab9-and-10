import React from 'react'
import Navbar from '../components/Navbar'

function ContactPage() {
  return (
    <>
    <Navbar activeTab="contact"/>
    </>
  )
}

export default ContactPage