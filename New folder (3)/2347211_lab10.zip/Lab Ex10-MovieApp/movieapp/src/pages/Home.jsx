import React from 'react'
import Navbar from '../components/Navbar'

function Home() {
  return (
    <Navbar/>
  )
}

export default Home