import React from 'react'
import Navbar from '../components/Navbar'

function AboutPage() {
  return (
    <>
    <Navbar activeTab="about"/>
    </>
  )
}

export default AboutPage